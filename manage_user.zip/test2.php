<?php 
$num = 1;
if($num > 10){
    echo "มันมากกว่า";
}else{
    echo "มันน้อยกว่า";
}
?>